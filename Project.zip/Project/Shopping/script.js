function Product(id,name,price)
{
	this.id=id;
	this.name=name;
	this.price=price;
}
var p1 = new Product(1,"Minimal Style Planter with Stand",3499)
var p2 = new Product(2,"Happy Face Planter",1299)
var p3 = new Product(3,"Aqua with grey ceramic planter",499)
var p4 = new Product(4,"Matte black Planter",849)
var p5 = new Product(5,"Tuscan Planter",1299)
var p6 = new Product(6,"Cup Saucer Terracotta Planter",999)
var p7 = new Product(7,"Teal Top Jute Basket",899)
var p8 = new Product(8,"Shimla hues Basket",749)
var p9 = new Product(9,"Chic White Beige Basket",699)
var p10 = new Product(10,"Strawberry Basket",524)
var p11 = new Product(11,"Minimal Cream Basket",699)
var p12 = new Product(12,"Rustic Striped Basket",699)
var p13 = new Product(13,"Hanging Terracotta Bowl Planters",1099)
var p14 = new Product(14,"Single Shelf Hanger",667)
var p15 = new Product(15,"Wall Mount Ring Plant Pot Holder",899)
var p16 = new Product(16,"Macrame Plant Hanger",649)
var p17 = new Product(17,"Metal Plant Bracket Hanger",499)
var p18 = new Product(18,"Coconut Shell Hanging Planter",799)
var p19 = new Product(19,"Bamboo Ladder Shelves",1299)
var p20 = new Product(20,"Plant Ladder Stand",999)
var p21 = new Product(21,"Plant Stand Shelf",1119)
var p22 = new Product(22,"Golden Cabbage, Red Onion, White Radish Seeds (Set of 3)",299)
var p23 = new Product(23,"Wild Rocket, White Radish, Lettuce Iceberg Seeds (Set of 3)",299)
var p24 = new Product(24,"Turnip, Celery, Pink Radish Seeds (Set of 3)",299)
var p25 = new Product(25,"Thyme, Basil Lemon, Parsley, Basil Purple, Basil Green Seeds (Set of 5)",449)
var p26 = new Product(26,"Turnip, Celery, Pink Radish, Spinach, Black Carrot Seeds (Set of 5)",449)
var p27 = new Product(27,"Wild Rocket, White Radish, Lettuce Iceberg, Pak Choi, Black Carrot Seeds (Set of 5)",449)
var p28 = new Product(28,"Seaweed Extract (Granules) 100g",249)
var p29 = new Product(29,"Doctor Green- Organic Plant Protection 200ml",249)
var p30 = new Product(30,"Bokashi Compost Maker",249)


var products = [p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23,p24,p25,p26,p27,p28,p29,p30];
var purchase = [];

function retrievePurchase()
{
	var purchase = JSON.parse(localStorage.getItem('purchases')?localStorage.getItem('purchases'):"[]");
	return purchase

}
function savePurchase()
{
	localStorage.setItem('purchases',JSON.stringify(purchase));
}
function updatePurchases(purch)
{
	localStorage.setItem('purchases',JSON.stringify(purch));

}
function savedetails()
{
	localStorage.setItem('products',JSON.stringify(products));
}

function refreshTotal(total)
{
	// console.log(total);
	var x = document.getElementById('totalLabel');
	x.innerText=total;
}
function refreshTable()
{
	$('#item-table-body').html('');
	var pur = retrievePurchase()
	var t = JSON.parse(localStorage.getItem('total'));
	var total=0;

	for(var p of pur)
	{
		var pq = (p.qty)*(p.price)
		$('#item-table').append("<tr> <td>" + p.id + " </td> <td>" + p.name + "</td> <td>" + p.price + " </td> <td>" + "  <button id=plus"+p.id+">+</button> "  + p.qty + "  <button id=sub"+p.id+">-</button>" +  "</td> <td>" + pq + " </td></tr>")
		total+=pq;	
	}


	$("button").click(function(e){
	    var idClicked = e.target.id;
	    var pp = retrievePurchase();
	    for(i=0;i<pp.length;i++)
	    {
	    	var ob=pp[i];
	    	if(("plus"+ob.id)===idClicked)
	    	{
	    		ob.qty++;
	    	}
	    	if(("sub"+ob.id)===idClicked)
    		{
	    		ob.qty--;
	    		if(ob.qty<=0)
	    		{
	    			pp.splice(i,1);

	    		}
    		}	

	    }

    	updatePurchases(pp)
    	refreshTable()
	});

	refreshTotal(total);
}

function checkPurchases(id)
{
	var pur = retrievePurchase();
	for(var p of pur)
	{
		if(p.id==id)
		{
			return p.qty;
		}
	}	

	return 0;

}

window.onscroll = function() {	scrollFunction()	};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

function topFunction() {
	// console.log("top button clicked")
    document.body.scrollTop = 0; 
    document.documentElement.scrollTop = 0;
}

	$(document).ready(function(){
  $('a[href^="#"]').on('click',function (e) {
      e.preventDefault();

      var target = this.hash;
      var $target = $(target);

      $('html, body').stop().animate({
          'scrollTop': $target.offset().top
      }, 900, 'swing', function () {
          window.location.hash = target;
      });
  });
});

$(function()
{
	savedetails()
	retrievePurchase();
	refreshTable();
	$("button").click(function(e)
	{
		var	idClicked = e.target.id;

		for(i=1;i<=30;i++)
		{
			if(idClicked===("btn"+i))
			{
				console.log(idClicked)
				purchase = retrievePurchase();
				var id=i;
				var det = getDetails(id);
				if(det!==0)
				{
					purchase.push({
						id:id,
						name:det.name,
						price:det.price,
						qty:det.qty
						});
				}
				savePurchase();
				retrievePurchase();	
				refreshTable();
			}

		}

	});
	
	function getDetails(id)
	{
		var pro;
		var containsAlready = checkPurchases(id);
		var inc = containsAlready+1;
		// console.log(containsAlready)
		var products = JSON.parse(localStorage.getItem('products'));
	if(containsAlready==0)
	{
		for(p of products)
		{

			if(p.id===id)
			{
				pro = 
				{
					name:p.name,
					price:p.price,
					qty:1
				}
			}
		}
	return pro
	}
	else
	{
		window.alert("This item exists in Cart. Kindly view your cart !");
		return 0;
	}

	}




})
